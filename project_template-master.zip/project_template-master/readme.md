This is a template for new projects.

```bash
pandoc writing.md -o writing.pdf
```
